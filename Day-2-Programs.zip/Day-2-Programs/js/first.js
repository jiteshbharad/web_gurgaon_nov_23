console.log("Hello World");
setTimeout(function(){ console.log("Bye")}, 1000);
console.log("Good Morning");

/* console.log("I am commented");

x=y+z; */
