
//1. while loop

//Syntax 

// initialization
// while(condition)
// {
//   statements;
// }

//Example 
// let i = 1;
// while(i < 10)
// {
//     console.log('hello');
//     i = i+1;
// }

//Example 
// let i = 1;
// while(i < 10)
// {
//     console.log(i);
//     i = i+1;
// }


//Sum of all integer no.s from 1 to 10.

// let sum = 0 ;
// sum = sum + 1;
// sum = sum + 2;
// sum = sum + 3;
// .
// .
// .
// sum = sum + 10;

// let sum = 0;
// let i = 1;
// while(i<=5)
// {
//     sum = sum + i;
//     i++;
// }
// console.log(sum);



//for loop example 
// let i ;
// for( i = 1 ; i<=10; i++)
// {
//     console.log(i);
// }
// console.log("outer i : ",i);


