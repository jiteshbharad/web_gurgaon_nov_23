var x=20;
let y=100;
let k;
const z=90;

x = 100;
y = 120;
//z = 130; // it is not allowed

console.log(x);//100
console.log(y);//120
console.log(z);//90
console.log(k);//undefined