// let cols =10;
// let rows = 6;
// for(let i = 1;i<=rows; i++)
// {
//     let s =  '';
    
//     for(let j = 1;j<=cols;j++)
//     {
//         s = s+ "*";
//     }
//     console.log(s);   
// }


let cols =3;
let rows = 6;
for(let i = 1;i<=rows; i++)
{
    let s =  '';
    
    for(let j = 1;j<=cols;j++)
    {
        s = s+ i;
    }
    console.log(s);   
}