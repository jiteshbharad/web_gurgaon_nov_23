console.log("Hello WOrld");
console.log("Good Morning");
document.write('Lorem Ipsum');