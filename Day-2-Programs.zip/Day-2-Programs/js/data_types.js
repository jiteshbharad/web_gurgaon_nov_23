

let x = 12;

console.log(x);
console.log(typeof x);

x = 'hello';

console.log(x);
console.log(typeof x);

let k = false;
console.log(typeof k);

let m;
console.log(typeof m);

let n = { name :'ramesh',rollno:'cs2' , marks:90.4 };
console.log(n);
console.log(typeof n);
console.log(n.name);//ramesh
console.log(n.marks);//90.4

let pqr = null;
console.log(typeof pqr);
console.log(typeof null);


function sum(a,b)
{
  return a+b;
}

let result=sum(12,100);
console.log(result);
console.log(typeof sum);