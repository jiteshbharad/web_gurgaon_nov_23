//1 . if

// let x = 132;
// let y = 12;
// let z = x+y;

// if(z > 200)
// {
//     console.log("hello");
// }

// console.log("world");


//2 if-else

// let age = 3;

// if(age >= 18)
// {
//     console.log("You can Vote")
// }
// else{
//     console.log("You can not vote");
// }

// console.log("Thank you !")


//3. If - else if - else 

// if(condition1)
// {
  
// }
// else if(condition2)
// {

// }
// else if(condition3)
// {

// }
// .
// .
// .
// else{

// }



//Switch Case 


// switch(variable)
// {
//     case val1 : 
//         statements; 
    
//     case val2:
//         statements;

//     case val3 :
//         statements;
// }


//Example 

// let x = 80;
// switch(x)
// {
//     case 10:
//     console.log('hello');
//     break;
    
//     case 8:
//     console.log("world");
//     break;
   
//     default: 
//     console.log("morning");
//     break;

//     case 12:
//     console.log("good");
//     break;
    
//     case 6 : 
//     console.log("bye");
// }





