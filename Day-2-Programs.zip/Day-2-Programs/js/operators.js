//Arithmetic Operators

let x = 12;
let y = 20;
let b = true;
let k = 'hello';
let z = x+y;
console.log(z);
let a = k + x;
console.log(a); 
console.log(typeof a);
console.log(k+b);//hellotrue

console.log(b+x);
console.log(b-x);

console.log(12-10);//2
console.log(12*10);//120
 console.log(true+true);
 console.log(true-true);


console.log(10/2);//5
console.log(30/2);//15
console.log(10/3);//3.333.....


console.log(10%3);//1
console.log(100%5);//0

// -------Arithmetic Operators End ---- //


//Logical Operators

let x1 = true; 
let x2 = true;
let x3 = false;

console.log(x1 && x2);//true 
console.log(x1 && x3); //false
console.log(x3 && x1); //false
console.log(x3 && x3); //false


console.log(false || true);//true
console.log(true || true);//true
console.log(true || false);//true
console.log(false || false);//false


console.log(!true);//false
console.log(!false);//true


//Relational Operators

console.log( 10 > 9);//true
console.log(10<9);//false
console.log(10 < 10);//false
console.log(10 <= 10);//true
console.log(109 >= 120);//false
console.log(120 >= 100);//true

console.log(12 == 12);//true
console.log(10 == 12);//false

let num1 = 120;
let num2 = "120";
let num3 = 120;
let num4 = "120";
console.log(num1 == num2);// true
console.log(num1 === num2);//false
console.log(num1 === num3);//true
console.log(num2 === num4);//true


console.log(12 != 10);//true
console.log(12 != 12);//false



//Ternary Operator

// (condition) ? val1 : val2;

let s1 = 12 ; let s2 = 19;
let result = (s1 < s2) ? 100 : 200;
console.log(result);