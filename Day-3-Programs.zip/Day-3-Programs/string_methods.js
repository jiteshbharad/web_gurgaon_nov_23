let s1 = "hello world";

console.log(s1.length);

let c = s1.charAt(4);
console.log(c);

let i =s1.indexOf('w');
console.log(i);

i = s1.indexOf('lo');
console.log(i);

i = s1.indexOf('l');
console.log(i);

i = s1.lastIndexOf('l');
console.log(i);

let result = s1.toUpperCase();
console.log(s1);
console.log(result);

result = result.toLowerCase();
console.log(result);

let str = "Hello world good morning";
result = str.startsWith("hello");
console.log(result);

result = str.startsWith("Hello");
console.log(result);

result = str.startsWith("Hello world good");
console.log(result);

result = str.endsWith('ng');
console.log(result)

result = str.endsWith('good morning');
console.log(result);

let str2 = "katappa killed bahubali in bahubali movie";

result = str2.replace('a','u');
console.log(result);

result = str2.replaceAll('a','u');
console.log(result);

result = str2.slice(5,11);
console.log(result);

result = str2.substring(9,20);
console.log(result);


let arr = str2.split(" ");
console.log(arr);

let fruitsStr ="apple,banana,orange,mango,grapes";
arr=fruitsStr.split(',');
console.log(arr);

