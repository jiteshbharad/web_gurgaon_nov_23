//break keyword in loop
// for(let i =1; i <= 10; i++)
// {
//     if(i == 6)
//     break;

//     console.log(i);
// }


//continue keyword in loop

// for(let i =1; i <= 10; i++)
// {
//     if(i == 6)
//       continue;

//     console.log(i);
// }

for(let i =1; i <= 50; i=i+2)
{
    if(i == 25)
      continue;

    console.log(i);
}
