//Object :  Any real world entity that has some attributes/data-members/properties and behaviour/methods/functionality and occupies some space/memory.

//Class : Class is a collection of similary type of objects.
          //Any no of objects can be created from a single class
          //Class is a blueprint/factory for creating objects.


//Class contains 1. Properties/Attributes/Data-member 
                //2. Behaviour/Methods
            
//Object contain  : 1 . properties/state  2. methods/behaviour  3. Identity/Memory Address


//Class Example
class Student{
   fname;
   lname;
   email;
   rollno;
    
    show(){
        console.log(this.fname);
        console.log(this.lname);
        console.log(this.email);
        console.log(this.rollno);
    }
}

//Create object
let s1=new Student();
let s2=new Student();

s1.fname='ramesh';
s1.lname='verma';
s1.email='rv@gmail.com';
s1.rollno=12;

s2.fname='suresh';
s2.lname='sharma';
s2.rollno=3;
s2.email='ss@gmail.com';

s2.show();
s1.show();





//1. Create a class Employee with attributes name, salary , department, and
//a method to display these details . 
//Create 2 instances of the class and assign values to their attributes and
//call display method on both.

//2. Create a class Rectangle with attributes length and width, and a method calculateArea() which will print the area of rectangle. Create 2 objects of rectangle class , initialize their attributes and call calculateArea() on both the objects.


class Rectangle{
    length;
    width;

    calculateArea()
    {
        // console.log(this.width*this.length);
        let area =  this.width*this.length;
        return area;
    }
}

let r1=new Rectangle();
let r2 = new Rectangle();

r1.length=10; r1.width=20;
r2.length=50; r2.width=100;

let area1=r1.calculateArea();
let area2=r2.calculateArea();

console.log(area1);
console.log(area2);







