class A{

    constructor()
    {
        this.x = 20;
    }
    show(){
        console.log(this.x);
    }
}

let a1 = new A();
a1.show();
a1.x = 132;
a1.show();

