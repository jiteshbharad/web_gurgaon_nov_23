//Constructor : Constructor is a special type of method present in a class that gets executed automatically at the time of object creation.

//Use : To initialize the properties with default values at the time of object creation

class A{
    a;
    b;
    constructor()
    {
        console.log('constructor called');
        this.a=10;
        this.b=20;
    }
    show()
    {
        console.log("a : ",this.a);
        console.log('b : ',this.b);
    }
}
//Constructor will be called once each for the whole lifecycle of an object
//Constructor can not be called explicity on object instance , it is only called implicitly.

let a1 = new A();//constructor called
let a2 = new A();//constructor called
// a1.show();
// a2.show();
a1.a=200;
a2.b = 300;

a1.show();// a : 200 
          // b : 20

a2.show();// a : 10
          // b : 300