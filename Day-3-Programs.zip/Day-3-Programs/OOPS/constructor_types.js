
//1  Default Constructor : Constructor with no arguments

//Previous example

//2 Parameterized Constructor : Constructor with some arguments/parameters.

// class A{

//     a;
//     b;
//     constructor(val1, val2)
//     {
//         this.a = val1;
//         this.b = val2;
//     }
//     show(){
//         console.log('a : ',this.a,' b : ',this.b);
//     }
// }

// let obj1 = new A(100,200);
// let obj2 = new A(40,60);
// obj1.show();// a:100 b:200
// obj2.show();// a:40 b:60

// class A{

//     constructor(val1, val2)
//     {
//         this.a = val2;
//         this.b = val1;
//     }
//     show(){
//         console.log('a : ',this.a,' b : ',this.b);
//     }
// }
// let obj1 = new A(2,5);
// obj1.show();



//3 . Copy Constructor 

// Instead of a value , an existing object of same type is passed as argument. It is used to create a new object whose properties are initialized with the properties of some already existing object.




