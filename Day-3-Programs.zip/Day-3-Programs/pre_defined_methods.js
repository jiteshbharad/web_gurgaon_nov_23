//Number

let x = 23;
console.log(typeof x);//number
let result = x.toString();
console.log(typeof result);


// let y = false; 
// console.log(typeof y);
// result = y.toString();
// console.log(typeof result);


let s = 129099;
result = s.toLocaleString();
console.log(result);


let n1 = 145.57;
result = n1.toPrecision(4)
console.log(result);