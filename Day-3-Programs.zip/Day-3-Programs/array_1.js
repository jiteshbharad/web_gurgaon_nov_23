//Array  ? Collection of elements stored in contiguos memory locations. The order of insertion is maintained.

//Why ? Reduces the programmers effort to operate on collection of elements


// let x = [12,90,100,89,1];
// console.log(typeof x);
// console.log('first element ',x[0]);
// console.log('fifth element ',x[4]);
// console.log(x[0]+x[2]);

// console.log(x.length);//length is the property of any array object 
// console.log('last element : ',x[x.length-1]);

// x[2]= 70;
// console.log(x);
// x[x.length] = 60;//insert element at end
// console.log(x);

// x.push(120);
// x.push(300);

// console.log(x);
// console.log(x.pop()+"has been deleted");
// console.log(x);

// x.unshift(100);

// console.log(x);

// console.log(x.shift()+'has been deleted');
// console.log(x);


// let a1 = [1,2,3];
// let a2 = [4,5,6];

// let a3 =  a1.concat(a2);

// console.log(a1);
// console.log(a2);
// console.log(a3);

// a1.reverse();
// console.log(a1);

// let a4 = [10,20,40,60,100,900];
// let a5=a4.slice(1,4);//slice from starting index 1 upto 4 , 4 is exclusive
// console.log(a5);
// let a6 = a4.slice(1);//slice from starting index 1 upto end of array
// console.log(a6);

// let a7 = [10,20,40];
// let result = a7.toString();
// console.log(result);
// console.log(typeof result);

// result = a7.join("");
// console.log(result);

// result = a7.join("and");
// console.log(result);


//Callback Function : A function that is passed as an argument to another function is called callback function . They are needed to make a function's execution order depenedent on another as javascript is by default async.


//Array Filter function
// function pass(num)
// {
//     if(num>70)
//       return true;
//     else 
//       return false;
// }

// let arr2 = [ 1, 2 , 4, 100, 89, 76 , 59 , 19];

// let result = arr2.filter(pass);

// console.log(result);


// Array map : used to map all the elements of the array to some new value


// function double(num)
// {
//     return 2*num;
// }

// let arr = [1,2,10,4,65];

// let result = arr.map(double);

// console.log(result);


// function double(x,y)
// {
//     if(y%2==0)
//     {
//         return 2*x;
//     }
//     return x;
// }

// let arr = [10,20,100,40,65];
// let result = arr.map(double);
// console.log(result);



//ForEach in array

// function print(x,y)
// {
//     console.log(x);
// }

// let x = [100,200,400,900];

// x.forEach(print);

//WAP to print only even elements of the array 

//let x = [  1, 2 , 3, 10, 11, 90, 87, 100];

// for(let i =0; i<x.length;i++)
// {
//     if(x[i]%2 == 0){
//         console.log(x[i]);
//     }
// }

// x.forEach(function(value){ 
//     if(value%2==0)
//     {
//         console.log(value)
//     }
// });


let arr = [10,20,90,5,6,7,11,15];

let result = arr.sort(function(x,y){
    return y-x;
});

console.log(result);


