//Collection : Group of objects where certain operations are defined.

//Set : Set is a collection of unique , unordered elements. In javascript , to create set type of collection , we have a predefined class "Set".

// let s1 = new Set();

// s1.add(12);
// s1.add(90);
// s1.add(100);
// s1.add(8);
// s1.add(9);

// console.log(s1.size);//5
// s1.add(90);
// console.log(s1.size);//5

// console.log(s1.has(120));//false
// console.log(s1.has(90));//true

// s1.delete(90);
// console.log(s1.size);//4
// console.log(s1.has(90));//false


//WAP to remove duplicy of elements from an array.



let x = [12,90,14,90,100,67,90,14,1,2,100];

let temp_set = new Set();
let result = [];

for(let i =0;i<x.length;i++)
{
    temp_set.add(x[i]);
}

console.log(temp_set);