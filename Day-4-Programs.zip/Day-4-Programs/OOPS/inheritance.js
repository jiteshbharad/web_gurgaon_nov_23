//Note : Javascript at its very core supports object inheritance using prototype inheritance. Class inheritance is the feature provided by es6.

//Inheritance : Inheritance is the property of any class to extend the capabilities of some already existing class.

//Benefit ? Code reusability  , hence development time reduces.'

class A{
    a=10;
    b=20;

    greet()
    {
        console.log("hello world good morning");
    }
}

class B extends A{
    c=30;
    show()
    {
        console.log(' a : ',this.a," b : ",this.b," c : ",this.c);
    }
}

let obj = new B();
obj.greet();
obj.show();
