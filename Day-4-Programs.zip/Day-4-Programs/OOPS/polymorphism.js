//Polymorphism : Polymorphism is the property of methods according to which a method with single name can have multiple implementations.

//Benefit ? name resuability of methods .
          // dynamic binding of methods.

//Can be acheived using 2 ways : 1. Overloading  2. Overriding

// Overloading : When a single class contains multiple methods with same name but different arguments , then such methods are called overloaded methods and this phenomenon is called method/function overloading. It is a feature of compiled languages , thus not supported in javascript. We can try to acheive similar thing in js using var args.


// class Arithmentic{

//     sum(...x){
//         let len = x.length;
//         let result = 0;
//         for(let i = 0 ;i<len;i++)
//         {
//             result = result + x[i];
//         }
//         console.log(result);
//     }
// }
// let obj = new Arithmentic();
// obj.sum(1,2);//3
// obj.sum(10,20,40);//70
// obj.sum(9,100,23,4);//136



//Overriding : For overriding, inheritance is the base. When a method/function of base class is redefined  in derived class , then such function/method is called overriden method/function and this phenonmenon is called function/method overriding.


class A{
    a;
    b;
    constructor(a,b){
        this.a=a;
        this.b=b;
    }
    sumAll()
    {
        console.log(this.a+this.b);
    }
}
class B extends A{
    c;
    d;
    constructor(a,b,c,d){
        super(a,b);
        this.c=c;
        this.d=d;
    }
    sumAll(){
        console.log(this.a+this.b+this.c+this.d);
    }
}
let aObj = new A(10,20);
let bObj =  new B(1,2,3,4);
aObj.sumAll();//30 --> Jump to line 40
bObj.sumAll();//10 --> Jump to line 53

