class A{
    x;
    y;

    constructor(a,b)
    {
        this.x=a;
        this.y=b;
    }
}

class B extends A{
    j;
    k;
    constructor(a,b,c,d){
        super(a,b);
        this.j=c;
        this.k=d;
    }
    show()
    {
        console.log(this.x, this.y , this.j , this.k);
    }
}

class C extends A{
    m;
    n;
    o;
    constructor(a,b,c,d,e)
    {
        super(a,b);
        this.m=c;
        this.n=d;
        this.o=e;
    }
    show()
    {
        console.log(this.x, this.y , this.m , this.n, this.o);
    }
}
let bObj = new B(10,20,30,40);
let cObj = new C(1,2,3,4,5);

bObj.show();//10 20 30 40
cObj.show();// 1 2 3 4 5


//Create a class Person with properties name, age , mobile , email. 
//Create a class Student which is child of Person , with more proerties : rollno, phyMarks , chemMarks , mathMarks
//Create a class Employee which is child of Person with more properties : empid , basic_salary, ta , hra.

//Create proper constructors and their heirarchy.
//Create a method in Employee class calculate_total_salary() which prints the total salary , total salary = basic + hra + ta
//Create a method in Student class calculate_total_marks which prints the total marks.

//Create object of student and employee and call these methods on them.