//Class can have properties and behaviour.

//Properties/data-members  and methods/behaviours can be of 2 types 

//a. instance members : instance variables , instance methods
//b. static members :  static variables, static methods


//instance variables : The variables specific to object which are the part of object, they are different for different objects and can not be shared.They will get memory only when object is created and each for a different object. If n objects are created then n copies of instance variable will be created. These are accessed on object name.

//Static variables : Those which are not part of object and hence not dependent on object. These are accessed on class name. they can be declared with the help of static keyword.


// class A{

//     x;//instance variable
//     static y;//static variable

//     show(){
//         console.log(this.x);
//         console.log(A.y);
//     }
// }

// A.y= 23;
// let obj1 = new A();
// let obj2 = new A();
// obj1.x = 12;
// obj2.x = 50;
// obj1.show();
// obj2.show();


//static and instance methods

class Arithmetic{
    num1;
    num2;
    
    constructor(x,y){
        this.num1=x;
        this.num2=y;
    }
   
    static sum(a,b)//this is not at all using any instance variable
    {
     console.log(a+b);   
    }

    sumAll()//this is using instace variables of class
    {
        console.log(this.num1+this.num2);
    }
    display()
    {
        console.log(this.num1);
    }
    static greet()
    {
        console.log("Hello world");
    }
}
Arithmetic.sum(100,200);//300
Arithmetic.sum(500,600);//1100
let obj = new Arithmetic(10,20);
let obj2 = new Arithmetic(50,60);
obj.sumAll();//30
obj2.sumAll();//110
