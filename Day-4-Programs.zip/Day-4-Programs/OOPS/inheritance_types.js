//Types of Inheritance 

//1. Single  2. Multilevel 3. Multiple 4. Hierarchical 5.Hybrid


//Sigle : Prev examples

//Multilevel : 
// class A{
//     a;
//     constructor(){
//         console.log("A class constructor");
//         this.a = 10;
//     }
// }
// class B extends A{
//     b ;
//     constructor()
//     {
//         super();
//         console.log("B class constructor");
//         this.b = 20;
//     }
// }
// class C extends B{
//     c;
//     constructor()
//     {
//         super();
//         console.log("C class constructor");
//         this.c = 30;
//     }
//     show(){
//         console.log(this.a);
//         console.log(this.b);
//         console.log(this.c);        
//     }
// }

// let obj = new C();
// obj.show();

// class A{
//     a;
//     constructor(){
//         console.log("A class constructor");
//         this.a = 10;
//     }
// }
// class B extends A{
//     b ;
//     constructor()
//     {
//         super();
//         console.log("B class constructor");
//         this.b = 20;
//         this.a=100;
//     }
// }
// class C extends B{
//     c;
//     constructor()
//     {
//         super();
//         console.log("C class constructor");
//         this.c = 30;
//         this.b = 200;
//     }
//     show(){
//         console.log(this.a);
//         console.log(this.b);
//         console.log(this.c);        
//     }
// }

// let obj = new C();
// obj.show();


//Multiple Inheritance   : not supported in javascript

//Hierarchical 

class A {
    a;
    constructor()
    {
        console.log("A constructor")
        this.a =10;
    }
}

class B extends A{
    b;
    constructor()
    {
        super();
        console.log("B constructor")
        this.b = 20;
    }

    show()
    {
        console.log('a : ',this.a,' b: ',this.b);
    }
}
class C extends A{
    c;
    constructor()
    {
        super();
        console.log("C constructor")
        this.c = 30;
    }
    show()
    {
        console.log('a : ',this.a,' c: ',this.c);
    }
}

let cObj = new C();
let bObj = new B();
bObj.show();//a : 10 b : 20
cObj.show();//a : 10 c : 30



//Hybrid : Combination of any 2 or more types of inheritance.