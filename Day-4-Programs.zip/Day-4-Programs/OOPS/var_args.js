function sum(...args)
{
    let len = args.length;
    let sum = 0;
    for(let i = 0;i < len ;i++)
    {
        sum = sum + args[i];
    }
    return sum;
}

console.log(sum(1,2));//3
console.log(sum(1,3,10));//14
console.log(sum(10,20,10,40));//80