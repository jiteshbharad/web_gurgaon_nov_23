
//Encapsulation : Encapsulation is the process of wrapping up data members and methods that work on them , together in a single entity known as class.

//Encapsulation encompasses : 1. Access specifiers 
//                             2. Getters/Setters

class A{
    
    x;//public
    #y;//private
    
    constructor(a,b)
    {
        this.x = a;
        this.#y = b;
    }
    show()
    {
        console.log(this.x);
        console.log(this.#y);
    }
}
let obj = new A(1,2);
obj.show();//1 2
obj.x = 12;
// obj.#y = 300;//error , as #y is private
obj.show();//12 2