//Constructors behaviour in Inheritance. Also known as constructor chaining.

//It is must to call the constructor of base class in the very first line of constructor of derived class.

// class A{
//     constructor()
//     {
//         console.log("A class constructor");
//     }
// }

// class B extends A{

//     constructor()
//     {        
//         super();//it will call the constructor of base class ie.A
//         console.log("B class constructor");
//     }
// }

// new B();




class A{
    a;
    constructor()
    {
        this.a = 10;
    }
}

class B extends A{
    constructor()
    {
        super();
        this.a = 20;
    }
    show()
    {
        console.log(this.a);
    }    
}
let bobj = new B();
bobj.show();