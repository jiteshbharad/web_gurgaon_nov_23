class Student{

    name;
    #marks;

    get marks()
    {
        return this.#marks;
    }

    set marks(val)
    {
        console.log('setter called');
        if(val>=0 && val<=100)
        {
            this.#marks = val;
        }
        else{
            console.log("Invalid marks");
        }
    }

    show()
    {
        console.log(this.name);
        console.log(this.#marks);
    }
}

let s=new Student();
s.name="ramesh";
s.marks= 89;//this will execute setter function marks(89)
console.log(s.marks);//this will execute getter function marks
s.show();