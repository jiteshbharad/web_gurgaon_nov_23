
//1  Default Constructor : Constructor with no arguments

//Previous example

//2 Parameterized Constructor : Constructor with some arguments/parameters.

// class A{

//     a;
//     b;
//     constructor(val1, val2)
//     {
//         this.a = val1;
//         this.b = val2;
//     }
//     show(){
//         console.log('a : ',this.a,' b : ',this.b);
//     }
// }

// let obj1 = new A(100,200);
// let obj2 = new A(40,60);
// obj1.show();// a:100 b:200
// obj2.show();// a:40 b:60

// class A{

//     constructor(val1, val2)
//     {
//         this.a = val2;
//         this.b = val1;
//     }
//     show(){
//         console.log('a : ',this.a,' b : ',this.b);
//     }
// }
// let obj1 = new A(2,5);
// obj1.show();



//3 . Copy Constructor 

// Instead of a value , an existing object of same type is passed as argument. It is used to create a new object whose properties are initialized with the properties of some already existing object.

class A{
    constructor(...args)
    {
        if(args[0] instanceof A)
        {//copy constructor
            this.x = args[0].x;
            this.y = args[0].y;
        }
        else{//parameterized constructor
            this.x = args[0];
            this.y = args[1];
        }
    }

    show(){
        console.log(this.x);
        console.log(this.y);
    }
}

let a1 = new A(1,2);
let a2 = new A(a1);
let a3 = new A(10,20,40,50);
a1.show();
a2.show();
a3.show();
//console.log(a1 instanceof A);true
//console.log(a3 instanceof A);false


//Constructor Overloading : Single class having multiple constructors , each having different arguments is known as constructor overloading. But javascript does not directly supports constructor overloading , so there is a workaround by using variable args concept.





//1. Create a class Rectangle with properties length and width, and method
//calculateArea which prints the area. You are required to initialize
//the proeprties using parameterized constructor.


//2. In the above class , in the constructor add the code so that it can
//act as copy constructor too. Create 2 objects , one using parameterized constructor , another  using copy constructor and pass the 1st object as argument to copy constructor.














